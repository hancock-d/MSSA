﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod7Overloadingdemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            A objA= new A();
            objA.Method1();
            B objB= new B();
            objB.Method1();
           
            A obj1=new B();// cross referencing
            // state of object (variables/ properties) is that of LHS . in this cass
            // it is from A
            // you can invoke the method from child class provided it is overriden and cross referencing 
            //is done. in this case from B
           
            obj1.Method1();

            // utility class typically holds functions together  and may not need properties to hold data
            // make the functions as static
            OutputFormatter.DisplayName("Deepali"); // first

            OutputFormatter.DisplayName("Deepali", "Kamatkar");// second

            // B obj2=new A(); not allowed


            Service firstservice = new Service();
            firstservice.ServiceId = 1;
            firstservice.ServiceName = "Create";
            firstservice.StartService(1, "Create");
            Console.WriteLine($"is service running {firstservice.IsRunning}");

            Console.ReadKey();
        }
    }
}
