﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod7Overloadingdemo
{
    // dynamic polymorphism
    internal class A
    {
       // protected int i;
        private int id;
        public int Id
        {
            get { return id; }
            set { id = value; }

        }
        public virtual void Method1()
        {
            Console.WriteLine("In method1 from class A");
        }
    }
    class B:A
    {
        public void Method2()
        { }
        public string Name { get; set; }
        public override void Method1()
        {
            Console.WriteLine("In method1 from class B");
        }
    }
}
