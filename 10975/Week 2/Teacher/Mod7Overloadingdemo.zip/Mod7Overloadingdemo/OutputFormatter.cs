﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod7Overloadingdemo
{
    // static polymorphism
    // Overloading: writing same named method within the same class but with different number of parameters
    // or different type of parameter
    // overloading: within class
    // overriding: across the classes in inheritance
    // static classes cannot be instantiated and derived from
    internal static class OutputFormatter
    {
        
        private static void Test()
        {

        }
        public static  void DisplayName(string firstname)
        {
            Test();
            Console.WriteLine($"Welcome {firstname} , enjoy the course! ");
        }
        public static void DisplayName(string firstname, string lastname)
        {
            Console.WriteLine($"Hello {firstname}  {lastname}, welcome to the course!");
        }
    }
   


}
