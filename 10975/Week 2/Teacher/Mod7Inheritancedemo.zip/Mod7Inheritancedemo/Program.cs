﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod7Inheritancedemo
{
    //client code
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount account = new BankAccount();
           
            SavingsAccount savingsAccount = new SavingsAccount(); // setting min balance
            savingsAccount.AccountNumber = 224242;
            savingsAccount.HolderName = "Frank S";
            Console.WriteLine($"For account {savingsAccount.AccountNumber} please set the balance:");
            double balance=double.Parse( Console.ReadLine() );
            if(balance>=savingsAccount.MinBalance)
            {
                savingsAccount.Balance=balance;
            }

            // logic to do transactions
            Console.WriteLine($"Balance is {savingsAccount.Balance}");
            Console.ReadKey();

            CheckingAccount checkingAccount = new CheckingAccount();
            Console.WriteLine($"min balance for checkin is {checkingAccount.MinBalance}");
            Console.ReadKey();
            
        }
    }
}
