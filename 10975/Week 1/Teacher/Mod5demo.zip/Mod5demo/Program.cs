﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod5demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            float result;
            // label: a named location
            inputnumbers:
            Console.WriteLine("Enter 2 numbers:");

            // 3o
            bool flag1=int.TryParse(Console.ReadLine(), out num1);
            bool flag2=int.TryParse(Console.ReadLine(), out num2);

            try
            {

                if (flag1 && flag2 ) // conversion was successfull
                {
                    result = num1 / num2;
                    Console.WriteLine($"Result is {result}");
                }
                else
                {
                    Console.WriteLine("Numbers are invalid, please reenter");
                    goto inputnumbers; // jump to 16
                }
            }
            catch(FileNotFoundException ex)
            {

            }
            catch(SqlException ex)
            {

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);// write error in logfile
                Console.WriteLine("Please enter non zero denominator");
                goto inputnumbers;
            }
            finally
            {
                // mandatory code like closing files, closing db connections
            }
            Console.ReadKey();
        }
    }
}
