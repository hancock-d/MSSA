﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod4Arraydemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Array is a fixed size collection of same data type, where memory is allocated continouosly
             * allocated in heap memory. Elements can be accessed by their index and by default the first
             * index is 0
             * datatype [] nameofarray=new int [size]
             * 
             */


            // 5 integer elements
            int[] numbers = new int[5];
            numbers[0] = 1;
            numbers[1] = 2;
            numbers[2] = 3;
            numbers[3] = 4;
            numbers[4] = 5;
            //  numbers[5] = 6; this is out of range
            Console.WriteLine("Array demo");
            Console.WriteLine("Please enter 5 numbers");
            for(int i=0;i<numbers.Length; i++)
            {
                numbers[i]=int.Parse(Console.ReadLine());   
            }
            Console.WriteLine("You entered the following numbers");
            for(int i=0 ; i<numbers.Length ; i++)
            {
                Console.Write(numbers[i] + " ");
            }
            Console.WriteLine();
            float[] temperatures = { 56.5f, 66f, 70.4f }; // size 3 and initialized


            //Nullable<float>[] temps = new Nullable<float>[3];
            
            Array.Resize(ref temperatures, 5);
            foreach(float f in temperatures)
            {
                Console.WriteLine(f);
            }

            string[] names = { "Zoe", "Amy", "Frank", "Nathan" };
          


           
            Array.Sort(names);
            Array.Reverse(numbers);
            Console.WriteLine("Reversed number array is as follows:");
            foreach(int i in numbers)
            {
                Console.WriteLine(i);
            }
            // foreach loop doesn't need the index. use the foreach mainly while doing reading /
            //iteration
            Console.WriteLine("Sorted array is");
            foreach(string name in names)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("How many hobbies you have?");
            int numOfHobbies=int.Parse(Console.ReadLine());

            string[]hobbies=new string[numOfHobbies];
            Console.WriteLine($"Please enter {numOfHobbies} hobby/hobbies ");

            for(int i=0;i<numOfHobbies;i++)
            {
                Console.WriteLine($"Hobby[{i+1}]:");
                hobbies[i] = Console.ReadLine();
            }
            Console.WriteLine("You have great hobbies:");
            foreach(string s in hobbies)
            { Console.WriteLine(s); }
          //  temperatures[3] = 67f; error

            List<string> cities = new List<string>();
            
            Console.ReadKey();
                    
        }
    }
}
