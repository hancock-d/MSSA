﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod2Demo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Variables and data types demo");

            // data type variable name
            int i;// 32 bit signed number
            char c = 'n';// initialize 
            float rateOfInterest = 2.4f;
            string name;
            string address;
            float age;
            Console.WriteLine("Please enter your name");
            name=Console.ReadLine();
            Console.WriteLine(name + ", where do you live?");
            address=Console.ReadLine();

            Console.WriteLine("Oh , you live in " +  address + " how old are you?");

            age=Convert.ToSingle(Console.ReadLine());

            int num1, num2;
            Console.WriteLine("Enter num1 and num2");
            num1= Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine());
            int result=num1 + num2;
            Console.WriteLine("Sum is " +  result);

            float divResult=num1 / num2;
            float remainder=num1 % num2 ;
            Console.WriteLine(divResult);
            Console.WriteLine(remainder);
            Console.ReadKey();
        }
    }
}
