﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace Mod1Demo1
{ // marks scope
    internal class Program
    {
        //starting point
        static void Main(string[] args)
        {// main starts

            
            int num = 10;
            Console.WriteLine(num);
            Console.ForegroundColor = ConsoleColor.Cyan;// assigning color to foreground property
            Console.WriteLine("Hello World!");// prints on the screen
            Console.ReadKey();// read a character
        }// main ends
        
    }
}
