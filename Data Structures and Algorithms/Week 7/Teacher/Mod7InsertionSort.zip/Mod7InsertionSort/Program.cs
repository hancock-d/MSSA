﻿namespace Mod7InsertionSort
{
    internal class Program
    {
        // O(nsq), stable
        static void InsertionSort(int[]A)
        {
            int temp = 0;
            int position = 0;
            for(int i=1; i<A.Length; i++)
            {
                temp = A[i];
                position = i;
                while(position>0 && A[position-1] > temp)
                {
                    A[position] = A[position-1];
                    position--;
                }
                A[position] = temp;
            }
        }

        static void Main(string[] args)
        {
            int[] A = { 3, 5, 9, 8, 6, 2 };
            InsertionSort(A);
        }
    }
}
