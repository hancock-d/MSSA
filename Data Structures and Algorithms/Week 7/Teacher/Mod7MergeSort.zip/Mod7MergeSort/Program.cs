﻿namespace Mod7MergeSort
{
    internal class Program
    {

        static void divide(int[]A,int left,int right)
        {
            if(left < right)
            {
                int mid=(left+right)/2;
                divide(A,left,mid);
                divide (A,mid+1,right);
                merge(A,left,mid,right);
            }
        }
        static void merge(int[]A,int left,int mid,int right)
        {
            int i = left;//first index of left sub array
            int j = mid + 1;//first index of right sub array
            int[]B=new int[right+1];// temp array which will hold merged elements
            int k = left;// index to track the elements in array B
            while(i<=mid && j<=right)
            {
                if (A[i] <= A[j])
                {
                    B[k] = A[i];
                    i++;
                }
                else
                {
                    B[k] = A[j];
                    j++;
                }
                k++;
            }
            while(i<=mid) // there were more elements in left array
            {
                B[k]= A[i];
                i++;
                k++;
            }
            while(j<=right)// there are more elements in right array
            {
                B[k] = A[j];
                j++;
                k++;
            }
            for(int x=left; x<=right; x++)
            {
                A[x]= B[x];// put back the sorted sub part in main array
            }
        }

        static void Main(string[] args)
        {
            int[] A = { 34, 12, 1, 45, 9, 11 };
            divide(A, 0, A.Length - 1);
            foreach(int x in A)
                Console.WriteLine(x);
            Console.ReadKey();
            //Console.WriteLine("Hello, World!");
        }
    }
}
