﻿namespace Mod7SelectionSort
{
    internal class Program
    {

        //[3 5 9 8 6 2]
        // minposition=0, i=0, j=1
        //if(5 < 3) ..do nothing
        //j=2 if(9<3)..do nothing
        //j=3 if(8<3) ..do nothing
        //j=4 if(6<3) ..do nothing
        //j=5 if(2<3)..minposition=5 found a num which is lesser than 3---> [2 5 9 8 6 3]
        // i=1, minposition=1, j=2
        //if(5

        // unstable, O(nsq)
        static void SelectionSort(int[]A)
        {
            int minPosition = 0;// to track the position of min element in exisiting array
            int temp = 0;
            for(int i=0; i<A.Length-1; i++)
            {
                minPosition = i;
                for(int j=i+1; j<A.Length; j++)// to get the min element's index position
                {
                    if (A[j] < A[minPosition])
                    {
                        minPosition = j;// update the minposition to newly found min element's position
                    }
                    
                   
                }
                //swap:
                if (minPosition != i)
                {
                    temp = A[i];
                    A[i] = A[minPosition];
                    A[minPosition] = temp;

                }
            }
        }
        static void Main(string[] args)
        {
          int[] A = {3,5,8,9,6,2};
          SelectionSort(A);
           Console.WriteLine("Sorted array");
           foreach(int i in A) Console.WriteLine(i);
            Console.ReadKey();
        }
    }
}
