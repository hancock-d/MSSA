﻿

namespace LINQDemo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // LINQ: language integrated querry 
            //string querry = "selet * from Emp";
            int[] scores = { 23, 45, 12, 400, 355 };//data source
            var scoreresults = from score in scores
                               where score > 40
                               select score;
            Console.WriteLine("Scores greater than 40");

            foreach (var item in scoreresults)
            {
                Console.WriteLine(item);
            }

            List<string> names = new List<string> { "Bill", "Alex", "James", "Rob" };
            var result_A=(from name in names
                         where name.StartsWith('A')
                         select name).ToList(); // forced

            names.Add("Andrew");
            // deferred
            Console.WriteLine("Names starting with A:");
            foreach (var item in result_A)
            {
                Console.WriteLine(item);
            }

            /*from name in collection
             * where 
             */
            Console.ReadKey();
        }
    }
}
