﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod7CodeFirstdemo.Data
{
    public static class Records
    {
        public static EmployeeContext employeeContext;
    }
}
