using Mod7CodeFirstdemo.Models;
using Mod7CodeFirstdemo.Services;

namespace Mod7CodeFirstdemo
{
    public partial class Form1 : Form
    {
        CRUD crud;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            crud = new CRUD();
            empGrid.DataSource = crud.GetEmployees();
            empGrid.Columns[4].Visible = false;
            btnSubmit.Enabled = false;
            btnUpdate.Enabled = false;
            foreach (var d in crud.GetDepartments())
            {
                comboDept.Items.Add(d.DepartmentName);
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtEid.Text = (crud.GetMaxId() + 1).ToString();
            txtEid.ReadOnly = true;
            txtName.Clear();
            txtSalary.Clear();
            btnSubmit.Enabled = true;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEid.Text) && !string.IsNullOrEmpty(txtName.Text))
            {
                if (comboDept.SelectedIndex != -1)
                {
                    var newemp = new Employee();
                    newemp.EmpId = int.Parse(txtEid.Text);
                    newemp.Name = txtName.Text;
                    newemp.Salary = double.Parse(txtSalary.Text);
                    newemp.DepartmentId = comboDept.SelectedIndex + 1;
                    crud.AddRecord(newemp);
                    MessageBox.Show("Record addedd!");
                }
            }
            btnSubmit.Enabled = false;
            empGrid.DataSource = crud.GetEmployees();
            Clear();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var id = empGrid.CurrentRow.Cells[0].Value;
            crud.DeleteRecord((int)id);
            MessageBox.Show("Record deleted!");
            empGrid.DataSource = crud.GetEmployees();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            var id = empGrid.CurrentRow.Cells[0].Value;
            var emptoupdate = crud.FindEmployee((int)id);
            txtEid.Text = emptoupdate.EmpId.ToString();
            txtEid.ReadOnly = true;
            txtName.Text = emptoupdate.Name;
            txtSalary.Text = emptoupdate.Salary.ToString();
            comboDept.SelectedIndex = emptoupdate.DepartmentId - 1;
            btnUpdate.Enabled = true;
        }

        private void Clear()
        {
            txtEid.Clear();
            txtName.Clear();
            txtSalary.Clear();
            comboDept.SelectedIndex = -1;

        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            var id=int.Parse(txtEid.Text);
            var emptoupdate=crud.FindEmployee((int)id);
            emptoupdate.Name = txtName.Text;
            emptoupdate.Salary=double.Parse(txtSalary.Text);
            emptoupdate.DepartmentId = comboDept.SelectedIndex + 1;
            crud.UpdateRecord(id, emptoupdate);
            MessageBox.Show("Record updated!");
            empGrid.DataSource = crud.GetEmployees();
            btnUpdate.Enabled = false;
            Clear();
        }
    }
}
