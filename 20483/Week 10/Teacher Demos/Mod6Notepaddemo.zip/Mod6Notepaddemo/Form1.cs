using System.IO;
using System.Net.Sockets;
namespace Mod6Notepaddemo
{
    public partial class Form1 : Form
    {
        string filepath;
        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextArea.Clear();
            richTextArea.Focus();
            saveToolStripMenuItem.Enabled = true;
            saveAsToolStripMenuItem.Enabled = true;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "Text Files(*.txt)|*.txt";
            openFile.Title = "Open text files";
            openFile.ShowDialog();
            if (openFile.FileName != string.Empty)
            {
                filepath = openFile.FileName;
                richTextArea.Text = File.ReadAllText(filepath);
            }
            saveToolStripMenuItem.Enabled = true;
            saveAsToolStripMenuItem.Enabled = true;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (File.Exists(filepath))
            {
                File.WriteAllText(filepath, richTextArea.Text);
            }
            else
            {
                SaveFileDialog saveFile = new SaveFileDialog();
                saveFile.Filter = "Text Files(*.txt)|*.txt";
                if (saveFile.ShowDialog() == DialogResult.OK)
                {
                    filepath = saveFile.FileName;
                    Stream stream = saveFile.OpenFile();
                    StreamWriter writer = new StreamWriter(stream);
                    writer.WriteLine(richTextArea.Text);
                    writer.Close();
                    stream.Close();
                }
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "Text Files(*.txt)|*.txt";
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                filepath = saveFile.FileName;
                Stream stream = saveFile.OpenFile();
                StreamWriter streamWriter = new StreamWriter(stream);
                streamWriter.WriteLine(richTextArea.Text);
                streamWriter.Close();
                stream.Close();
                // streamWriter.Close();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.ShowDialog();
            richTextArea.SelectionFont = fontDialog.Font;
            ColorDialog colorDialog = new ColorDialog();
            colorDialog.ShowDialog();
            richTextArea.SelectionColor = colorDialog.Color;
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextArea.SelectedText);
            richTextArea.SelectedText=string.Empty;
        }
    }
}
