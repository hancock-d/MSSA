﻿namespace LINQDemo1
{
    internal class Program
    {
        public delegate bool MyDel(int n);

        public delegate int SumDel(int n1, int n2);
        static void Main(string[] args)
        {
            SumDel sum = (x1, x2) =>
            {
                 return (x1 + x2)*100;

            };
            var temp = sum(34, 45);

            var result = CheckNum(40);// normal function call
            var myDel = new MyDel(CheckNum);
            
            var newresult = myDel(50);// calling function via delegate

            // anonymous methods
            MyDel pointer = delegate (int num)
            {
                return (num > 500);
            };

            var result1 = pointer(50);

            // lambda expressions
            MyDel pointer2 = (x) =>
            {
                return (x > 1000);
            };

            var result2 = pointer2(500);

        }
        static bool CheckNum(int num)
        {
            if(num>500)return true;
            return false;
        }
    }
}
