﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod5Demo1
{
    internal class A
    {
        private int id;
        protected int x;
    }
    class B : A
    {
        public void Test()
        {
            
        }
    }
    class C : B
    {
        public void Test2()
        {
            
        }
    }


}
