﻿namespace Mod5Demo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name,name1;
            name = "deep0li";
            Console.WriteLine($"Contains digit :{name.ContainsNumbers()}");
            List<int> ints = new List<int>() { 2,3,4,5};

            Console.WriteLine($"Product: {ints.Product()}");


            int i = 30;
            int j = 70;
            i.CheckValue(j);
           
            A obj=new A();
            B obj2 = new B();
            
            Coffee mycoffee = new Coffee(1, "Arabica");
            Coffee yourcoffee = new Coffee();

            try
            {
                //code to check loyalty card
                throw new LoyaltyCardNotFoundException();
            }
            catch (LoyaltyCardNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            CustomList list=new CustomList();
           
            Console.ReadKey();
        }
    }
}
