﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Mod5Demo1
{
    internal static class ExtensionMethodsClass
    {
        public static bool ContainsNumbers(this string s)
        {
            return Regex.IsMatch(s, "\\d");
        }
        public static bool CheckValue(this int obj,int val)
        {
            return obj > val;
        }
        public static int Product(this List<int> ints)
        {
            int product = 1;
            foreach (int i in ints)
            {
                product *= i;   
            }
            return product;
        }
    }
}
