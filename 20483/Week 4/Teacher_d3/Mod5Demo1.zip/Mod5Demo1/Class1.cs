﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod5Demo1
{
    abstract class Beverage
    {
        private int id;
        public int Id { get { return this.id; } }
        public string Name { get; set; }
        public Beverage(int id)
        {
            
            this.id= id;
        }
        public Beverage()
        {


        }
        public abstract double CalculatePrice();
        public virtual void SetBaseTemp()
        {
            throw new NotImplementedException();
            //logic
        }
    }

     class Coffee:Beverage
    {
        public Coffee(int id,string bean):base(id)
        {
            this.Bean = bean;
        }
        public Coffee()
        {

        }
        public string Bean {  get; set; }
        public sealed override void SetBaseTemp()
        {
           // base.SetBaseTemp();
        }
        public override double CalculatePrice()
        {
            throw new NotImplementedException();
        }
    }
    // sealed for classes : stopsinheritance
    // sealed for methods: stops overriding

    class Espresso : Coffee
    {
       
    }

}
