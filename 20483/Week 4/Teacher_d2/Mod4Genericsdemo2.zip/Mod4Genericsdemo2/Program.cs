﻿namespace Mod4Genericsdemo2
{

    class Person
    {
        public string Name { get; set; }
        public int PhoneNumber { get; set; }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2;
            n1 = 34;
            n2 = 56;
           // Swap<int>.SwapData(ref n1, ref n2);

            Swap<int> swapint = new Swap<int>();
            swapint.SwapData(ref n1, ref n2);

            float f1, f2;
            f1 = 3.4f;
            f2 = 5.6f;
            Swap<float> swapfloat = new Swap<float>();
            swapfloat.SwapData(ref f1, ref f2);
            Stack<int> stack = new Stack<int>();
            CustomList<int> customList = new CustomList<int>();

            Dictionary<string, Person> phonebook = new Dictionary<string, Person>();
            phonebook.Add("Zoe", new Person() { Name = "Zoe", PhoneNumber = 2424242 });
            phonebook.Add("Amy", new Person() { Name = "Amy", PhoneNumber = 2424244 });

            foreach(Person p in phonebook.Values)
            {
                Console.WriteLine(p.Name + " " + p.PhoneNumber);

            }

            Console.ReadKey();
        }
        static void swap(ref int x, ref int y)
        {
            int temp;
            temp = x;
            x = y;
            y = temp;
        }
        static void swap(ref float x, ref float y)
        {
            float temp;
            temp = x;
            x = y;
            y = temp;
        }
    }
}
