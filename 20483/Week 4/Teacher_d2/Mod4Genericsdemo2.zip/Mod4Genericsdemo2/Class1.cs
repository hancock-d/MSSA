﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod4Genericsdemo2
{

    // exe : main , it starts when i double click on exe
    //.dll : collection of classes/ structs/ delegates
     abstract class  Conversions // utility
    {
        
        public  static double CelciustoFahrenheit(double celcius)
        {
            int temp;
            return (celcius * 9 / 5) + 32;
        }

    }

    class A:Conversions
    {

    }

}
