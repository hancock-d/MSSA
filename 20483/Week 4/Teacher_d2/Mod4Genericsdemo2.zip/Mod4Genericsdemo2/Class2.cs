﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod4Genericsdemo2
{
    // T: place holder for data type
    internal  class Swap<T>
    {
        public void SwapData(ref T num1, ref T num2)
        {
            T temp;
            temp = num1;
            num1 = num2;
            num2 = temp;
        }
    }

    class CustomList<T>
    {
        public T[] items;
        public CustomList()
        {
            items = new T[50];
        }
        public T GetValue(int index)
        {
            return items[index];
        }
        public void Add(T item)
        {
            //logic

        }
    }



}
