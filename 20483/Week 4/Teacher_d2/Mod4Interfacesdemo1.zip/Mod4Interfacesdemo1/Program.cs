﻿namespace Mod4Interfacesdemo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MathCal mathCal = new MathCal();
            
        }
    }
}
