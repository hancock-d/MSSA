﻿namespace Mod4Interfacesdemo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>() { 200, 100, 30, 1000 };
            list.Sort();
            foreach (int i in list)
                    Console.WriteLine(i);


            List<string> names = new List<string>() { "Nathan", "Jim", "Don" };
            names.Sort();
            foreach (string name in names)
                Console.WriteLine(name);

            List<Student> students = new List<Student>();
            students.Add(new Student() { Id=1, Age=12, GPA=4.5f, Name="Zach"});
            students.Add(new Student() { Id = 2, Age = 8, GPA = 3.0f, Name = "Frank" });
            students.Add(new Student() { Id = 3, Age = 11, GPA = 4f, Name = "Elizabeth" });
            students.Add(new Student() { Id = 4, Age = 14, GPA = 5.0f, Name = "Alex" });
            students.Sort(); // Icomparable (compareTo)
            foreach(Student student in students)
                Console.WriteLine(student.Name + " " + student.Age);

            Console.WriteLine("GPA sorting");
            students.Sort(new StudentGPAComparer());// icomparer
            foreach(Student student in students)
                Console.WriteLine(student.Name + " "+ student.GPA);
            Console.ReadKey();
        }
    }
}
