﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod2MethodDemo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // signature : name + parameters ( types + number)
            //named parameters, flexibility in oreder, readable
            CalculateTax(baseSalary: 56565, state: "ny", filingType: 'M', dependants: 0, contributions: 5466);
          //  System.IO.File.WriteAllText(path: "", contents: "hgghg");
            CalculateTax(baseSalary: 55656, state: "nc", contributions: 77, dependants: 1);
            int sum;
            long product;
            int[] values = new int[5] { 34, 45, 67, 88, 45 };
            // if there are multiple return types of different datatypes then use out
            Results( out sum, out product, values);
            int num1 = 34, num2 = 78, num3 = 8787;
            Results(out sum, out product, num1, num2, num3);
            Console.WriteLine($"sum :{sum} and product: {product}");
            Console.ReadKey();
        }
        
        static void Add(int i,int j)
        {
            Console.WriteLine(i +j);
        }
        static int Add(int i,int j,int k)
        {
            return i +j+k;
           // Console.WriteLine( i + j + k);
        }
        // optional parameters: specify the default value any parameter would take in and you can omit 
        //passing value to it, but can also send a value if needed. this does not create a overload
        // optional parameters must be at the end
        static void CalculateTax(double baseSalary,string state,double contributions=0,int dependants=0,char filingType='S')
        {
            //logic
        }

        static void Results(out int sum,out long product, params int[] values)
        {
            product = 1;
            sum = 0;
            foreach(int i in values)
            {
                product=product*i;
                sum=sum+i;
            }
        }


    }
}
