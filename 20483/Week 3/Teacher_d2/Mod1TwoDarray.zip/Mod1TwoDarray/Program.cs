﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod1TwoDarray
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float[,] temperatures;// size: row*col=4*4=16
                                  // datatype [,] name=new datatype[rows,cols] , rows*cols
                                  //temperatures = new float[20, 30];

            // int[,,] ints=new int[2,2,2]  3d array

            Console.WriteLine("2D array demo");
            Console.WriteLine("Enter the number of cities (rows)");
            int rows=int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the temperatures received per city (cols)");
            int cols=int.Parse(Console.ReadLine());
            temperatures=new float[rows, cols];
            Console.WriteLine($"Please enter {rows * cols} readings of temperature");
            for(int i=0; i<rows; i++) // outer loop
            {
                for(int j=0; j<cols; j++)// inner loop
                {
                    Console.Write($"City[{i},{j}]");
                    temperatures[i,j]=float.Parse(Console.ReadLine());

                }
            }
            Console.WriteLine("Your entered temperatures are:");
            for(int i=0;i<temperatures.GetLength(0);i++)//rows
            {
                for(int j=0;j<temperatures.GetLength(1);j++)//cols
                {
                    Console.Write(temperatures[i, j] + "\t");

                }
                Console.WriteLine();
            }

            Console.ReadKey();

        }
    }
}
