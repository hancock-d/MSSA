﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod1Jaggedarraydemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //array of arrays
            Console.WriteLine("Jagged array demo");
            int[][] temp_cities = new int[4][]; // decide number of rows(cities)

            for(int i = 0;i < temp_cities.Length;i++)// how many rows/ cities/ arrays
            {

                Console.WriteLine($"Enter the number of readings you expect for city{i}");
                int readings=int.Parse(Console.ReadLine());
                temp_cities[i]=new int[readings]; // allocate size to horizontal row
                for(int  j = 0;j < temp_cities[i].Length;j++)// how many in each of row/city/array
                {
                    Console.Write($"temp_cities[{i}][{j}]");
                    temp_cities[i][j] = int.Parse(Console.ReadLine());

                }

            }

            Console.WriteLine("Temp readings");
            for(int i=0;i< temp_cities.Length;i++)
            {
                Console.Write($"City {i}:");
                for(int j=0;j< temp_cities[i].Length; j++)
                {
                    Console.Write(temp_cities[i][j] + "F\t");
                }
                Console.WriteLine();

            }
            Console.ReadKey();

        }
    }
}
