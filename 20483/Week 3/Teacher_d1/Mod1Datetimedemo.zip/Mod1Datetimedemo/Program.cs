﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod1Datetimedemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] names = { "Amy", "Alex", "Adam", "Zoe", "Frank" };
            // LINQ:Language integrated Query exprssions
            // select name from Tablename where...sql
            // 1. use of var
            var names_A = from name in names
                          where name.StartsWith("A")
                          select name;

            Console.WriteLine("Names starting with A");
            // 2. foreach
            foreach(var n in names_A)
            {
                Console.WriteLine(n);
            }
            // var obj = new EMP();


            Console.WriteLine($"It is {DateTime.Now.ToLongDateString()}  ");

            Console.WriteLine("Enter your date of birth in yyyy/mm/dd");

            var dob=Convert.ToDateTime(Console.ReadLine());

            var age=CalculateAge(dob);
            Console.WriteLine($"You are {age} years young!");
            var months = ((DateTime.Now.Year * 12) + DateTime.Now.Month) - ((dob.Year * 12) + dob.Month);
            float preciseAge = months / 12.0f;
            Console.WriteLine($"Precise age: {preciseAge} years");
            Console.ReadKey();

        }

        static int CalculateAge(DateTime dateofbirth)
        {
            return DateTime.Now.Year- dateofbirth.Year;
        }


    }
}
