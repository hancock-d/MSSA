﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod2OperatorOverloading
{
    internal class Circle
    {
        public double Radius {  get; set; }
        private double area;
        public double Area
        {
            get
            {
                CalculateArea();
                return this.area;
            }
        }
        private void CalculateArea()
        {
            this.area=Math.PI*this.Radius*this.Radius;
        }
        public static Circle operator +(Circle c1,Circle c2)
        {
            Circle cnew = new Circle();
            cnew.Radius= c1.Radius + c2.Radius;
            cnew.CalculateArea();
            return cnew;
        }



    }
}
