﻿namespace Mod2OperatorOverloading
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            a = 3;
            b = 4;
            int c = a + b;
            string fname, lname;
            fname = "Deepali";
            lname = "Kamatkar";
            string fullname=fname+ " "+lname;

            Console.WriteLine($"Hello,{fullname} !");

            Circle c1 = new Circle();
            Circle c2 = new Circle();
            c1.Radius = 12;
            c2.Radius = 10;

            Circle c4 = new Circle();
            c4.Radius = 5;
            Circle c3 = c1 + c2+c4;

            Circle smallcircle= new Circle();
            //smallcircle = c1 - c2;
            Console.WriteLine($"Result of c1+ c2 is {c3.Radius} , area:{c3.Area}");
            Console.ReadKey();
        }
    }
}
