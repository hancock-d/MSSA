﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod3EmpSystem
{
    // wrapper
    internal class Data
    {
        public static List<Employee> Employees = new List<Employee>();
    }
}
