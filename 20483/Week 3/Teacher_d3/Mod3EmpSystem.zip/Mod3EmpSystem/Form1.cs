namespace Mod3EmpSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if(txtUsername.Text=="HR" && txtPassword.Text=="Password")
            {
                MessageBox.Show("Welcome HR!");
                MainForm mainForm = new MainForm();
                mainForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid attempt, please login again!");
                txtUsername.Clear();
                txtPassword.Clear();
            }

        }
    }
}
