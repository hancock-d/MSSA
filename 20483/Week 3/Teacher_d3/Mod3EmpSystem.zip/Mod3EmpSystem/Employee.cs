﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod3EmpSystem
{
    enum Department
    {
        IT=1,
        Finance,
        HR,
        Marketing
    }
    internal class Employee:Person
    {
        public int EmployeeId {  get; set; }
        public double Salary {  get; set; }
        public Department Dept { get; set; }
    }
}
