﻿namespace Mod3EmpSystem
{
    partial class AddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpEmployee = new GroupBox();
            btnSubmit = new Button();
            comboDept = new ComboBox();
            txtSalary = new TextBox();
            txtAddress = new TextBox();
            txtName = new TextBox();
            txtEid = new TextBox();
            lblDept = new Label();
            lblSalary = new Label();
            lblAddress = new Label();
            lblName = new Label();
            lblEmpId = new Label();
            grpEmployee.SuspendLayout();
            SuspendLayout();
            // 
            // grpEmployee
            // 
            grpEmployee.Controls.Add(btnSubmit);
            grpEmployee.Controls.Add(comboDept);
            grpEmployee.Controls.Add(txtSalary);
            grpEmployee.Controls.Add(txtAddress);
            grpEmployee.Controls.Add(txtName);
            grpEmployee.Controls.Add(txtEid);
            grpEmployee.Controls.Add(lblDept);
            grpEmployee.Controls.Add(lblSalary);
            grpEmployee.Controls.Add(lblAddress);
            grpEmployee.Controls.Add(lblName);
            grpEmployee.Controls.Add(lblEmpId);
            grpEmployee.Font = new Font("Calibri Light", 12F);
            grpEmployee.Location = new Point(204, 107);
            grpEmployee.Name = "grpEmployee";
            grpEmployee.Size = new Size(451, 315);
            grpEmployee.TabIndex = 0;
            grpEmployee.TabStop = false;
            grpEmployee.Text = "Employee Record";
            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(174, 273);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(75, 36);
            btnSubmit.TabIndex = 10;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // comboDept
            // 
            comboDept.FormattingEnabled = true;
            comboDept.Location = new Point(229, 229);
            comboDept.Name = "comboDept";
            comboDept.Size = new Size(149, 27);
            comboDept.TabIndex = 9;
            // 
            // txtSalary
            // 
            txtSalary.Location = new Point(229, 185);
            txtSalary.Name = "txtSalary";
            txtSalary.Size = new Size(149, 27);
            txtSalary.TabIndex = 8;
            txtSalary.Validating += txtSalary_Validating;
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(229, 134);
            txtAddress.Multiline = true;
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(149, 33);
            txtAddress.TabIndex = 7;
            // 
            // txtName
            // 
            txtName.Location = new Point(229, 88);
            txtName.Name = "txtName";
            txtName.Size = new Size(149, 27);
            txtName.TabIndex = 6;
            // 
            // txtEid
            // 
            txtEid.Location = new Point(229, 51);
            txtEid.Name = "txtEid";
            txtEid.Size = new Size(149, 27);
            txtEid.TabIndex = 5;
            txtEid.Validating += txtEid_Validating;
            // 
            // lblDept
            // 
            lblDept.AutoSize = true;
            lblDept.Location = new Point(33, 229);
            lblDept.Name = "lblDept";
            lblDept.Size = new Size(156, 19);
            lblDept.TabIndex = 4;
            lblDept.Text = "Employee Department";
            // 
            // lblSalary
            // 
            lblSalary.AutoSize = true;
            lblSalary.Location = new Point(33, 185);
            lblSalary.Name = "lblSalary";
            lblSalary.Size = new Size(117, 19);
            lblSalary.TabIndex = 3;
            lblSalary.Text = "Employee Salary";
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Location = new Point(33, 137);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(128, 19);
            lblAddress.TabIndex = 2;
            lblAddress.Text = "Employee Address";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(33, 91);
            lblName.Name = "lblName";
            lblName.Size = new Size(116, 19);
            lblName.TabIndex = 1;
            lblName.Text = "Employee Name";
            // 
            // lblEmpId
            // 
            lblEmpId.AutoSize = true;
            lblEmpId.Location = new Point(33, 51);
            lblEmpId.Name = "lblEmpId";
            lblEmpId.Size = new Size(89, 19);
            lblEmpId.TabIndex = 0;
            lblEmpId.Text = "Employee Id";
            // 
            // AddForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(grpEmployee);
            Name = "AddForm";
            Text = "AddForm";
            Load += AddForm_Load;
            grpEmployee.ResumeLayout(false);
            grpEmployee.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox grpEmployee;
        private Label lblDept;
        private Label lblSalary;
        private Label lblAddress;
        private Label lblName;
        private Label lblEmpId;
        private TextBox txtSalary;
        private TextBox txtAddress;
        private TextBox txtName;
        private TextBox txtEid;
        private Button btnSubmit;
        private ComboBox comboDept;
    }
}